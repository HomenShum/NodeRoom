---
name: source-pack-review
description: "How to review the diligence source pack: folder map, line citations, superseded documents, diligence-call exceptions and restricted documents. Use before extracting any figure from sources/."
---

# Source pack review

## Folder map

| Folder | Contents | Use for |
|---|---|---|
| `sources/companies/` | one profile per company | business model, segment, leadership, funding history |
| `sources/financials/` | one statement per company (sometimes more than one version) | ARR, growth, gross margin, burn, cash |
| `sources/diligence-calls/` | one call note per company | exceptions, restatements, top risk |
| `sources/market/` | market, competitor, regulatory and committee notes | context and committee thresholds only |
| `sources/inbox/` | companies received after the first review | only when a task asks for them |
| `sources/restricted/` | blocked by workspace policy | never read; report as unavailable |

Every document puts one metric per line, so a line citation pins one number.

## Citation format

- `[src:sources/financials/example-financials.md#L37]` for one line,
  `[src:sources/diligence-calls/example-call-notes.md#L41-L43]` for a range.
- Paths are workspace-relative with forward slashes. Line numbers are 1-based.
- Put the citation right after the value it supports. Read the line again before citing it: the
  number in your table must appear on that line exactly as written there (`$24.2M` supports 24.2).

## Traps to check for every company

1. **Versions.** Read the header block (`Version:`, `Status:`, `Supersedes:`). A statement marked
   SUPERSEDED is never a source, even when it looks almost identical to its replacement. Cite the
   superseding version and name the superseded path in your summary.
2. **Exceptions in call notes.** A section headed `EXCEPTION` overrides company-reported figures
   (for example ARR restated after removing one-time revenue). Use the corrected value and cite the
   call-note line that states it, not the financial statement.
3. **Concentration and other flags.** Call notes record customer concentration, legal matters and
   liquidity concerns. The `Top risk:` line in the Findings section is the top risk for the table.
4. **Restricted references.** Call notes may point to documents in `sources/restricted/`. Do not
   open them. List each one by path as unavailable.
5. **Benchmarks are not metrics.** Figures in `sources/market/` describe peers or the market.

## Parallel review

Split the pack by folder: one helper each for companies, financials, diligence calls and market.
Ask each helper to return, per company, `{ metric, value, citation }` triples plus any version,
exception or restricted-document findings, with citations. Merge in the main agent: call-note
exceptions win over statements; superseding versions win over superseded ones.
