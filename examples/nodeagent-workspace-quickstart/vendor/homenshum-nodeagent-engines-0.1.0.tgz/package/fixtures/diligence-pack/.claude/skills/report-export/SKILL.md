---
name: report-export
description: "Implement and test report/src/export.mjs, which exports the comparison table to CSV, markdown and JSON. Use when working in report/ or when the report check fails."
---

# Report export

## Contract

The full contract is the doc comment in `report/src/export.mjs`; the row model is in
`report/src/table.mjs`. In short, `exportReport(rows, { format })`:

- refuses the whole export when any field in `CITED_FIELDS` has no citation or a malformed one
  (the error names the company and the field and contains the word "citation");
- sorts by `runwayMonths.value` descending, ties by company name, without mutating the input;
- `csv`: header of `COLUMNS` labels plus `Sources`, RFC 4180 quoting for commas, quotes, CR and LF;
- `markdown`: a pipe table with a `Sources` column, `|` escaped as `\|`, line breaks as `<br>`;
- `json`: `{ "schema": "diligence.report/v1", "rows": [...] }`, row keys in `COLUMNS` order then
  `sources`, independent of input key order, two-space indent and a trailing newline;
- `Sources` = every citation of the row in column order, de-duplicated, joined by one space.

Use the helpers already exported by `table.mjs` (`COLUMNS`, `CITED_FIELDS`, `cellValue`,
`citationsOf`, `parseCitation`). The project has no dependencies; keep it that way.

## Testing

- Run the suite with the Node `run_checks` tool, check id `report` (it runs `node --test` in `report/`).
- Do not edit or delete anything in `report/test/`. A failing test is a defect in `export.mjs` or in
  `analysis/comparison.json`, never in the test.
- `report/test/comparison.test.mjs` loads `../analysis/comparison.json`, so it fails until the
  table exists with at least 8 cited rows whose citations point at real, non-restricted lines.
