---
name: diligence-notebook
description: "Build analysis/diligence.ipynb as a valid nbformat 4 notebook that recomputes runway (cash / monthly burn) from analysis/comparison.json and ranks the companies. Use when writing or updating the diligence notebook."
---

# Diligence notebook

## nbformat 4 structure

A notebook is a JSON file:

```json
{
  "cells": [
    { "cell_type": "markdown", "id": "intro", "metadata": {}, "source": ["# Title\n", "Text"] },
    { "cell_type": "code", "id": "load", "metadata": {}, "source": ["import json\n"], "execution_count": null, "outputs": [] }
  ],
  "metadata": { "kernelspec": { "name": "python3", "display_name": "Python 3", "language": "python" } },
  "nbformat": 4,
  "nbformat_minor": 5
}
```

- `source` is a string or a list of lines that keep their trailing `\n`.
- Code cells need `execution_count` (`null` when not executed) and `outputs` (`[]`).
- nbformat 4.5 wants a unique `id` on every cell.
- Never write fake outputs; leave code cells unexecuted unless you really ran them.
- If the Node notebook tool is available (search the tool catalog for "notebook"), use it to append
  cells; it keeps the file valid.

## Runway

- Runway (months) = cash and equivalents / average monthly net burn, both in USD millions.
- Use the values from `analysis/comparison.json`, which are already cited; do not re-type numbers.
- Assert that the stored `runwayMonths` matches the recomputed value within 0.1 month.

## Suggested cells (at least 6)

1. Markdown: purpose, as-of date, the runway formula.
2. Code: load `comparison.json` (the notebook lives in `analysis/`, so the path is `comparison.json`).
3. Markdown: how runway is recomputed and why a mismatch matters.
4. Code: recompute runway per company and check it against the table.
5. Markdown: ranking rule and committee thresholds (see `sources/market/` for the committee criteria note; cite it).
6. Code: rank by runway, longest first, and label each company against the thresholds.
7. Markdown: exceptions the ranking does not show (restatements, concentration, superseded or unavailable documents).
