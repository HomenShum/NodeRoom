import{J as g}from"./workbook-vendor-CUPSAa_W.js";const u="application/vnd.openxmlformats-officedocument.presentationml.presentation",y=new Date("1980-01-01T00:00:00.000Z");function v(e){const s=JSON.stringify(e);let t=2166136261;for(let a=0;a<s.length;a+=1)t^=s.charCodeAt(a),t=Math.imul(t,16777619);return(t>>>0).toString(16).padStart(8,"0")}function S(e){return e.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,72)||"deck"}function f(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;")}function c(e,s){const t=e.replace(/\s+/g," ").trim();return t.length<=s?t:`${t.slice(0,Math.max(0,s-1)).trim()}...`}function T(e,s){return`${S(e)}-deck-${s}.pptx`}function b(){return u}function o(e,s=1800,t="F3F6FB",a=!1){return`<a:p><a:r><a:rPr lang="en-US" sz="${s}"${a?' b="1"':""}><a:solidFill><a:srgbClr val="${t}"/></a:solidFill></a:rPr><a:t>${f(e)}</a:t></a:r></a:p>`}function i(e,s,t,a,m,l,d,p,n){const h=p?`<a:solidFill><a:srgbClr val="${p}"/></a:solidFill>`:"<a:noFill/>",x=n?`<a:ln w="12700"><a:solidFill><a:srgbClr val="${n}"/></a:solidFill></a:ln>`:"<a:ln><a:noFill/></a:ln>";return`<p:sp>
    <p:nvSpPr><p:cNvPr id="${e}" name="${f(s)}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
    <p:spPr><a:xfrm><a:off x="${t}" y="${a}"/><a:ext cx="${m}" cy="${l}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>${h}${x}</p:spPr>
    <p:txBody><a:bodyPr wrap="square" lIns="91440" tIns="73152" rIns="91440" bIns="73152"/><a:lstStyle/>${d}</p:txBody>
  </p:sp>`}function P(e){const s=e.claims.slice(0,5);return s.length===0?o("No claims yet.",1600,"AAB4C2"):s.map(t=>o(`${t.status.replace("_"," ")} - ${c(t.text,132)}`,1500,t.status==="verified"?"55D49A":t.status==="needs_review"?"E59579":"D7DEE9")).join("")}function F(e){const s=e.unresolvedGaps.slice(0,4);return s.length===0?o("No unresolved gaps on this slide.",1450,"8E98A7"):s.map(t=>o(`Review - ${c(t,120)}`,1450,"E59579")).join("")}function I(e,s){const t=e.status==="needs_review"?"E59579":"55D49A";return`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:cSld>
    <p:bg><p:bgPr><a:solidFill><a:srgbClr val="08090B"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>
    <p:spTree>
      <p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>
      <p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>
      ${i(2,"Slide number",457200,365760,548640,365760,o(String(s+1).padStart(2,"0"),1550,"E59579",!0),"241713","5A3529")}
      ${i(3,"Status",1021080,365760,2011680,365760,o(e.status.replace("_"," ").toUpperCase(),1180,t,!0))}
      ${i(4,"Title",457200,914400,8138160,731520,o(c(e.title,78),3e3,"F3F6FB",!0))}
      ${i(5,"Purpose",457200,1645920,8138160,731520,o(c(e.purpose,160),1650,"AAB4C2"))}
      ${i(6,"Claims",457200,2552700,8138160,1828800,P(e),"101317","252A32")}
      ${i(7,"Gaps",457200,4564380,8138160,914400,F(e),"101317","252A32")}
    </p:spTree>
  </p:cSld>
  <p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>
</p:sld>`}function L(){return`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>
</Relationships>`}function C(e){return`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" saveSubsetFonts="1">
  <p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>
  <p:sldIdLst>${e.slides.map((t,a)=>`<p:sldId id="${256+a}" r:id="rId${2+a}"/>`).join("")}</p:sldIdLst>
  <p:sldSz cx="9144000" cy="5143500" type="screen16x9"/>
  <p:notesSz cx="6858000" cy="9144000"/>
  <p:defaultTextStyle/>
</p:presentation>`}function $(e){return`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>
  ${e.slides.map((t,a)=>`<Relationship Id="rId${2+a}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${a+1}.xml"/>`).join("")}
</Relationships>`}function R(e){return`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
  <Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>
  <Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>
  <Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>
  <Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>
  ${e.slides.map((t,a)=>`<Override PartName="/ppt/slides/slide${a+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`).join("")}
</Types>`}const D=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>`,A=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
  <Application>NodeRoom</Application>
  <PresentationFormat>On-screen Show (16:9)</PresentationFormat>
  <Slides>0</Slides>
</Properties>`;function M(e){return`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:title>${f(e.title)}</dc:title>
  <dc:creator>NodeRoom</dc:creator>
  <cp:lastModifiedBy>NodeRoom</cp:lastModifiedBy>
  <dcterms:created xsi:type="dcterms:W3CDTF">1970-01-01T00:00:00Z</dcterms:created>
  <dcterms:modified xsi:type="dcterms:W3CDTF">1970-01-01T00:00:00Z</dcterms:modified>
</cp:coreProperties>`}const E=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree></p:cSld>
  <p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>
  <p:txStyles><p:titleStyle/><p:bodyStyle/><p:otherStyle/></p:txStyles>
</p:sldMaster>`,k=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/>
</Relationships>`,N=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" type="blank" preserve="1">
  <p:cSld name="Blank"><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree></p:cSld>
  <p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>
</p:sldLayout>`,_=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/>
</Relationships>`,w=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="NodeRoom">
  <a:themeElements>
    <a:clrScheme name="NodeRoom"><a:dk1><a:srgbClr val="08090B"/></a:dk1><a:lt1><a:srgbClr val="F3F6FB"/></a:lt1><a:dk2><a:srgbClr val="101317"/></a:dk2><a:lt2><a:srgbClr val="D7DEE9"/></a:lt2><a:accent1><a:srgbClr val="E59579"/></a:accent1><a:accent2><a:srgbClr val="55D49A"/></a:accent2><a:accent3><a:srgbClr val="6AA9FF"/></a:accent3><a:accent4><a:srgbClr val="A78BFA"/></a:accent4><a:accent5><a:srgbClr val="FFD16A"/></a:accent5><a:accent6><a:srgbClr val="AAB4C2"/></a:accent6><a:hlink><a:srgbClr val="6AA9FF"/></a:hlink><a:folHlink><a:srgbClr val="A78BFA"/></a:folHlink></a:clrScheme>
    <a:fontScheme name="NodeRoom"><a:majorFont><a:latin typeface="Aptos Display"/></a:majorFont><a:minorFont><a:latin typeface="Aptos"/></a:minorFont></a:fontScheme>
    <a:fmtScheme name="NodeRoom"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:lnStyleLst><a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme>
  </a:themeElements>
</a:theme>`;function r(e,s,t){e.file(s,t,{date:new Date(y.getTime()),createFolders:!1})}async function U(e,s=0){const t=e.slides.reduce((p,n)=>p+n.unresolvedGaps.length+n.claims.filter(h=>h.status!=="verified").length,0),a={deckId:e.deckId,planHash:e.planHash,title:e.title,slides:e.slides.map(p=>({id:p.slideId,title:p.title,purpose:p.purpose,status:p.status,claims:p.claims.map(n=>[n.claimId,n.text,n.status,n.evidenceId,n.traceId,n.proposalId]),gaps:p.unresolvedGaps}))},m=v(a),l=new g;r(l,"[Content_Types].xml",R(e)),r(l,"_rels/.rels",D),r(l,"docProps/core.xml",M(e)),r(l,"docProps/app.xml",A.replace("<Slides>0</Slides>",`<Slides>${e.slides.length}</Slides>`)),r(l,"ppt/presentation.xml",C(e)),r(l,"ppt/_rels/presentation.xml.rels",$(e)),r(l,"ppt/slideMasters/slideMaster1.xml",E),r(l,"ppt/slideMasters/_rels/slideMaster1.xml.rels",k),r(l,"ppt/slideLayouts/slideLayout1.xml",N),r(l,"ppt/slideLayouts/_rels/slideLayout1.xml.rels",_),r(l,"ppt/theme/theme1.xml",w),e.slides.forEach((p,n)=>{r(l,`ppt/slides/slide${n+1}.xml`,I(p,n)),r(l,`ppt/slides/_rels/slide${n+1}.xml.rels`,L())});const d=await l.generateAsync({type:"uint8array",compression:"DEFLATE",compressionOptions:{level:6},platform:"UNIX",streamFiles:!1});return{exportVersion:1,deckId:e.deckId,planHash:e.planHash,title:e.title,generatedAt:s,slideCount:e.slides.length,needsReviewCount:t,integrityHash:m,fileName:T(e.title,m),bytes:d}}export{U as b,b as d};
