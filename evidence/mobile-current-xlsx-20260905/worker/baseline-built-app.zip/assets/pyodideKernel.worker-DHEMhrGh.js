const y=new URL("/pyodide/",globalThis.location.origin).toString(),b=new URL("/pyodide/pyodide.mjs",globalThis.location.origin).toString();let l;globalThis.addEventListener("message",t=>{var e;((e=t.data)==null?void 0:e.type)==="run"&&f(t.data)});async function f(t){try{const e=await m(),o=x(e,t.code);if(o){_({type:"error",executionId:t.executionId,status:"blocked",errorCode:"python_policy_blocked",message:o});return}let r="",i="";e.setStdout({batched:s=>{r=p(r,s,t.limits.maxOutputBytes),_({type:"stream",executionId:t.executionId,channel:"stdout",text:s})}}),e.setStderr({batched:s=>{i=p(i,s,t.limits.maxOutputBytes),_({type:"stream",executionId:t.executionId,channel:"stderr",text:s})}}),e.globals.set("__noderoom_context_json",JSON.stringify(t.context??{})),e.runPython(`
import json as __noderoom_json
__noderoom_context = __noderoom_json.loads(__noderoom_context_json)
TABLES = __noderoom_context.get("tables", {})
ARTIFACTS = __noderoom_context.get("artifacts", [])
`);let n=await e.runPythonAsync(t.code);n==null&&e.globals.has("result")&&(n=e.globals.get("result"));const a=w(n),d=k(a,r,i,t.limits.maxRows);_({type:"result",executionId:t.executionId,output:d})}catch(e){_({type:"error",executionId:t.executionId,status:"failed",errorCode:"python_execution_failed",message:E(e)})}}async function m(){return l??(l=import(b).then(t=>t.loadPyodide({indexURL:y})).then(t=>(h(),t))),l}function h(){const t=()=>Promise.reject(new Error("Notebook network access is disabled.")),e=globalThis;e.fetch=t,e.WebSocket=class{constructor(){throw new Error("Notebook network access is disabled.")}},e.XMLHttpRequest=class{constructor(){throw new Error("Notebook network access is disabled.")}},e.EventSource=class{constructor(){throw new Error("Notebook network access is disabled.")}}}function x(t,e){t.globals.set("__noderoom_user_code",e);const o=t.runPython(`
import ast as __nr_ast
__nr_blocked_modules = {"js", "pyodide", "micropip", "socket", "urllib", "http", "requests", "aiohttp", "websockets", "subprocess", "multiprocessing", "ctypes", "importlib"}
__nr_blocked_calls = {"open", "exec", "eval", "compile", "__import__", "input", "breakpoint"}
__nr_error = None
try:
    __nr_tree = __nr_ast.parse(__noderoom_user_code, mode="exec")
    for __nr_node in __nr_ast.walk(__nr_tree):
        if isinstance(__nr_node, (__nr_ast.Import, __nr_ast.ImportFrom)):
            __nr_names = [__nr_alias.name.split(".")[0] for __nr_alias in __nr_node.names] if isinstance(__nr_node, __nr_ast.Import) else [(__nr_node.module or "").split(".")[0]]
            if any(__nr_name in __nr_blocked_modules for __nr_name in __nr_names):
                __nr_error = "Import is blocked by the notebook network/isolation policy."
                break
        if isinstance(__nr_node, __nr_ast.Call) and isinstance(__nr_node.func, __nr_ast.Name) and __nr_node.func.id in __nr_blocked_calls:
            __nr_error = "Dynamic code, file, and interactive input calls are blocked."
            break
        if isinstance(__nr_node, __nr_ast.Attribute) and __nr_node.attr.startswith("__"):
            __nr_error = "Dunder attribute access is blocked."
            break
except SyntaxError as __nr_exc:
    __nr_error = f"Python syntax error: {__nr_exc.msg}"
__nr_error
`);return typeof o=="string"&&o?o:null}function k(t,e,o,r){if(t&&typeof t=="object"){const n=t,a=Array.isArray(n.rows)?n.rows.slice(0,r):void 0,d=g(n.chart,r);return{outputText:typeof n.outputText=="string"?n.outputText:e||JSON.stringify(t),...a?{rows:a}:{},...d?{chart:d}:{},...o?{errorCode:"python_stderr"}:{}}}return{outputText:t==null?e||"Completed.":String(t),...o?{errorCode:"python_stderr"}:{}}}function g(t,e){if(!t||typeof t!="object")return;const o=t;if(!(!["line","bar","scatter"].includes(o.type)||typeof o.x!="string"||typeof o.y!="string"||!Array.isArray(o.points)))return{type:o.type,table:typeof o.table=="string"?o.table:"python",x:o.x,y:o.y,points:o.points.slice(0,e).map(r=>{const i=r&&typeof r=="object"?r:{};return{x:u(i.x),y:u(i.y)}})}}function u(t){return t===null||typeof t=="string"||typeof t=="number"||typeof t=="boolean"?t:String(t??"")}function w(t){var o;const e=t;if(e!=null&&e.toJs)try{return c(e.toJs({dict_converter:Object.fromEntries}))}finally{(o=e.destroy)==null||o.call(e)}return c(t)}function c(t){return t instanceof Map?Object.fromEntries([...t.entries()].map(([e,o])=>[String(e),c(o)])):Array.isArray(t)?t.map(c):typeof t=="bigint"?Number(t):t&&typeof t=="object"?Object.fromEntries(Object.entries(t).map(([e,o])=>[e,c(o)])):t}function p(t,e,o){const r=t?`${t}
${e}`:e;return new TextEncoder().encode(r).byteLength<=o?r:`${r.slice(0,Math.max(0,o/2))}...`}function E(t){return(t instanceof Error?t.message:String(t??"Python execution failed.")).replace(/\s+/g," ").slice(0,500)}function _(t){globalThis.postMessage(t)}
