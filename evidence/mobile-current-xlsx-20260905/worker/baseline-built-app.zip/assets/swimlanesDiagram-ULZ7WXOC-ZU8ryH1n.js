import{c as r,s as e}from"./flowDiagram-UKHOOZJN-yTwOfbbJ.js";import{_ as o}from"./mermaid.core-Cf0_hY9T.js";import"./graph-vendor-J0B54Dgy.js";import"./chunk-5VM5RSS4-DLHv7CV6.js";import"./chunk-XXDRQBXY-BOaYos51.js";import"./chunk-KBJHAD2P-hWl2-hWb.js";import"./chunk-2GRJ4B5K-7ti6yUPg.js";import"./channel-BembQkxC.js";import"./main-BRIwV4by.js";import"./react-vendor-Ba019tNT.js";import"./step-Cl5gnEYj.js";import"./editor-vendor-DfZ6aHfA.js";var a=o(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=a,v=r({defaultLayout:"swimlane",styles:m});export{v as diagram};
